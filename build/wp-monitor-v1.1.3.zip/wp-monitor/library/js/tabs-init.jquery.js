 jQuery( function() {
	 jQuery ( "#tabs" ).tabs();
	 jQuery("#tabs-dashboard").tabs();
 } );
